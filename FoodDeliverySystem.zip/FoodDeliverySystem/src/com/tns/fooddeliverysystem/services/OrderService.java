package com.tns.fooddeliverysystem.services;

import com.tns.fooddeliverysystem.entities.Customer;
import com.tns.fooddeliverysystem.entities.DeliveryPerson;
import com.tns.fooddeliverysystem.entities.Order;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class OrderService {
    private List<Order> orders = new ArrayList<>();
    private Map<Integer, DeliveryPerson> deliveryPersonMap = new HashMap<>();
    private int nextOrderId = 1;

    public Order createOrder(Customer customer) {
        Order order = new Order(nextOrderId++, customer);
        orders.add(order);
        return order;
    }

    public void assignDeliveryPersonToOrder(int orderId, int deliveryPersonId) {
        Order order = getOrderById(orderId);
        DeliveryPerson deliveryPerson = deliveryPersonMap.get(deliveryPersonId);

        if (order != null && deliveryPerson != null) {
            order.setDeliveryPerson(deliveryPerson);
            System.out.println("Delivery person assigned successfully!");
        } else if (order == null) {
            System.out.println("Order not found!");
        } else {
            System.out.println("Delivery person not found!");
        }
    }

    public void addDeliveryPerson(DeliveryPerson deliveryPerson) {
        deliveryPersonMap.put(deliveryPerson.getDeliveryPersonId(), deliveryPerson);
    }

    public List<Order> getAllOrders() {
        return orders;
    }

    private Order getOrderById(int orderId) {
        for (Order order : orders) {
            if (order.getOrderId() == orderId) {
                return order;
            }
        }
        return null;
    }
}
