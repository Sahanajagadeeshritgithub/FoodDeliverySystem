package com.tns.fooddeliverysystem.services;

import com.tns.fooddeliverysystem.entities.Customer;
import java.util.ArrayList;
import java.util.List;

public class CustomerService {
    private List<Customer> customerList = new ArrayList<>();

    public void addCustomer(Customer customer) {
        customerList.add(customer);
        System.out.println("Customer created successfully!");
    }

    public Customer getCustomer(int userId) {
        for (Customer customer : customerList) {
            if (customer.getUserId() == userId) {
                return customer;
            }
        }
        return null;
    }

    public List<Customer> getCustomers() {
        return customerList;
    }
}
